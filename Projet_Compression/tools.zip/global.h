#ifndef DEF_GLOBAL
#define DEF_GLOBAL

#define PAS_DANS_LE_DICO -1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "tools.h"
#include "codage.h"

#endif
