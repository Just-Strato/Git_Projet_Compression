#include "global.h"

int codeMot(const char *str) {
  if (strlen(str) == 1) {
    return str[0];
  }
  else {
    static int index;
    
    for (index = 0; index < DICO.nb_mots && strcmp(str, DICO.mots[index]); index++);
    if (index == DICO.nb_mots) return PAS_DANS_LE_DICO;
    
    return index + 256;
  }
}

void initDico() {
  DICO.nb_mots = 0;
  int i;
  for (i = 0; i < 3840; i++) {
    DICO.mots[i] = NULL;
  }
}

void delDico() {
  int i;
  for (i = 0; i < DICO.nb_mots; i++) {
    if (DICO.mots[i] != NULL) {
      free(DICO.mots[i]);
      DICO.mots[i] = NULL;
    }
    DICO.nb_mots = 0;
  }
}

void ajouterDico(char* mot) {
  if(DICO.nb_mots<4096) {
	  int k = strlen(mot) + 1;
    DICO.mots[DICO.nb_mots] = (char *)malloc(k * sizeof(char));
    strcpy_s(DICO.mots[DICO.nb_mots++],4096, mot);
  }
}

void afficherDico() {
  printf("\n=== Affichage du dictionnaire ===\n");
  
  int i;
  for (i = 0; i < DICO.nb_mots; i++) {
    printf("%i : '%s'\n", i + 256, DICO.mots[i]);
  }
}

void controlDico(char * S, char C)
{
  int lgth = strlen(S);
  
  S[lgth] = C;
  S[lgth + 1] = '\0';
  
  if (codeMot(S) == PAS_DANS_LE_DICO) {
    // On ajoute S+C au dictionnaire
    ajouterDico(S);
    
    // S devient c
    S[0] = C;
    S[1] = '\0';
  }
}

t_Code* codeur_lzw(char *message) {
  int message_length = strlen(message), k;
  char S[BUFSIZ] = { '\0' };
  int code = 0;
  t_Code *codage = NULL;
  codage = (t_Code *)malloc(sizeof(t_Code));
  codage->n = 0;
  
  for (k = 0; k < message_length; k++) {
    char C = message[k];
    int lgth = strlen(S);
    
    //S=S+C
    S[lgth] = C;
    S[lgth + 1] = '\0';
    
    if (codeMot(S) == PAS_DANS_LE_DICO) {
      ajouterDico(S);
      
      // retirer C
      S[lgth] = '\0';
      
      
      if (strcmp(S, "")) {
	//recupere le code de S
	code = codeMot(S);
	codage->tab[codage->n] = code;
	(codage->n)++;
      }
      
      // S devient C
      S[0] = C;
      S[1] = '\0';
    }
  }
  
  if (strcmp(S, "")) {
    int code = codeMot(S);
    codage->tab[codage->n] = code;
    (codage->n)++;
  }
  return codage;
}

void decodeur_lzw(int* message, int taille) {
  char S[BUFSIZ] = { '\0' };
  int lgth = 0;
  for (int k = 0; k < taille; k++) {
    int C = message[k];
    
    if (C < 256) {
      printf("%c",C);
      controlDico(S,C);
      lgth++;
    }
    else {
      //Affichage du mot
      char *mot = DICO.mots[C - 256];
      lgth += strlen(mot);
      //MAJ du dico
      int i;
      for (i = 0; i < strlen(mot); i++)
	{
	  printf("%c",mot[i]);
	  controlDico(S,mot[i]);
	  
	}
    }
  }
  printf(" message original de longueur %u\n", lgth);
}

FILE* ouvrirFlux(char *nom,char *mode) {
  FILE *pFILE = fopen(nom, mode);
  assert(pFILE != NULL);
  return pFILE;
}

void fermerFlux(FILE *pFILE) {
  assert(pFILE != NULL);
  fclose(pFILE);
}

void ecrireFichier(FILE *pFILE,T_TriplesOctet *tabTriples, t_octet *clef) {
  /*On ecrit dans le fichier la clef de cryptage des triples d'octets,
    le nombre de triples d'octets,
    et Les octets*/
  fwrite(clef, sizeof(t_octet), 1, pFILE);
  fwrite(&(tabTriples->n), sizeof(int), 1, pFILE);
  
  for(int k=0;k<tabTriples->n;k++){
    fwrite(tabTriples->tab[k], sizeof(Triples), 1, pFILE);
  }
}

T_TriplesOctet* lireFichier(FILE *pFILE, t_octet *clef)
{
  T_TriplesOctet* tabTriples = NULL; tabTriples= (T_TriplesOctet *)malloc(sizeof(T_TriplesOctet));
  assert(tabTriples != NULL );
  
  fread(clef,sizeof(t_octet),1,pFILE);
  fread(&(tabTriples->n), sizeof(int), 1, pFILE);
  tabTriples->tab=(Triples*)malloc(tabTriples->n * sizeof(Triples));
  
  for(int k=0;k<tabTriples->n;k++) {
    fread(&(tabTriples->tab[k]),sizeof(Triples),1,pFILE);
  }
  return tabTriples;
}

void afficherCode(const t_Code codage) {
  printf("============== Code ===============\n");
  printf("{" );
  for (int k=1;k<codage.n;k++)
    {
      printf(" %d,",codage.tab[k-1]);
      if((k%7)==0)
	printf("\n ");
    }
  printf(" %d }\n",codage.tab[codage.n-1]);
  printf("============== Fin ================\n");
}

void freeTriplesOctet(T_TriplesOctet *x) {
  free(x->tab);
  free(x);
}
