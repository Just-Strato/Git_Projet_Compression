#include "global.h"

int main(int argc, char** argv) {
  //char* message = argv[1];
  //char *message = "Viens boire un petit coup a la maison";
	char * message = "Message";
  FILE *pFILE;
  T_TriplesOctet* tabTriples;
  t_Code* codage;
  t_octet clef=0b10101010;
  initDico();
  int choix;
  
  printf("================================================\n");
  printf("============= Chiffrage du message =============\n");
  printf("================================================\n\n");
  
  codage=codeur_lzw(message);
  
  afficherCode(*codage);
  
  do{
    printf("\n\nAfficher le Dictionnaire ? ( 0:Nom/1:Oui ) :");
    scanf_s("%d",&choix);
  }while(choix!=1 && choix!=0);
  
  if(choix) afficherDico();
  
  pFILE=ouvrirFlux("flux.bin","w");
  
  tabTriples=compresserCode(codage);
  cryptageDecryptageTripletOctet(tabTriples,clef);
  
  ecrireFichier(pFILE,tabTriples,&clef);
  
  delDico();
  fermerFlux(pFILE);
  printf("\n\n\n=============Chiffrage du message de longueur %u fait =============\n",strlen(message));

  freeTriplesOctet(tabTriples);
  free(codage);
  
  return EXIT_SUCCESS;
}
