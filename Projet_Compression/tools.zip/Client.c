#include "global.h"

/*int main(int argc, char** argv) {
  
  FILE *pFILE;
  T_TriplesOctet* tabTriples;
  t_Code* codage;
  t_octet clef;
  initDico();
  int choix;
  
  printf("\n\n===================================\n");
  printf("============Dechiffrage============\n");
  printf("===================================\n\n");

  pFILE=ouvrirFlux("flux.bin","r");

  tabTriples=lireFichier(pFILE,&clef);
  cryptageDecryptageTripletOctet(tabTriples,clef);
  codage = decompresserCode(tabTriples);
  
  afficherCode(*codage);
  decodeur_lzw(codage->tab, codage->n);
  
  do{
    printf("\n\nAfficher le Dictionnaire ? ( 0:Nom/1:Oui ) :");
    scanf_s("%d",&choix);
  }while(choix!=1 && choix!=0);

  if(choix) afficherDico();

  delDico();
  free(codage);
  fermerFlux(pFILE);
  freeTriplesOctet(tabTriples);

  return EXIT_SUCCESS;
}*/
